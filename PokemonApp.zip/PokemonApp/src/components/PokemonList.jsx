import {useState} from "react";
const [pokemons, setPokemons] = useState([]);

function PokemonList() {
  return(
    <div>
      <h1>Pokemon Lijst</h1>
    </div>
  ); 
}

export default PokemonList;